interface Publisher {
  void publish(String topic, Event event);
}

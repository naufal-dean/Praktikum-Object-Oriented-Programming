interface Event {
  public String toString();
}

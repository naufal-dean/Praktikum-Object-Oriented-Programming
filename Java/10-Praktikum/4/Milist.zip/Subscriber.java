interface Subscriber {
  void onEvent(Event event);
}

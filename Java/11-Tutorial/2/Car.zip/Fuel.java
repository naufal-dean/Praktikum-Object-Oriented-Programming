public enum Fuel {
    PREMIUM, PERTAMAX, SOLAR
}